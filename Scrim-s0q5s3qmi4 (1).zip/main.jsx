import React, { useState } from "react";
import {getRecipeFromMistral}  from "./api"
import Recipe from "./components/recipe"
export default function Main() {
 
  const [ingredients,setIngredients]=React.useState([])

  const ingList=ingredients.map(ingredient=> (<li key={ingredient}>{ingredient}</li>))
const [recipe,setRecipe]= React.useState("")
  
  
  function SubmitIng (event)
  {
    event.preventDefault()
    const formData= new FormData(event.currentTarget)
    const newIng=formData.get("inpIng")
    console.log(newIng)
    setIngredients(ingredients=> [...ingredients,newIng])
    
  }
   async function getRecipe() {
        const recipeMarkdown = await getRecipeFromMistral(ingredients)
        setRecipe( recipe => recipeMarkdown)
    }
  function Clear(){
  setIngredients([])
  setRecipe("")
  }
  
    return (
    <>
      <h2>Enter the ingredients to generate a recipe</h2>
      <div className="main1">
      <form onSubmit={SubmitIng} >
        <input
          type="text"
          id="inpIng"
          name="inpIng"
          placeholder="e.g., Wheat"
        />
        <input
          type="submit"
          className="inpIng"
          value="Add"
        /> </form>
        <input type="reset"  className="clear" value="Clear" onClick={Clear}  />
      </div>
     <div className="ingList">
     { ingList.length>0 &&  <><h3> Ingredients List</h3> 
             <ul>{ingList} </ul>  

          <input
            type="submit"
            className="gen"
            value="Generate Recipe"
            onClick={getRecipe}
          /></> }
      </div>
     <Recipe recipe={recipe} /> 
    </>
  );
}
