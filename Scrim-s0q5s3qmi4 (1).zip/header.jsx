export default function Header() 
{
  return(<header className="head">
  <img src="images/22.png" />
      <h3> Chef's Cue </h3>
   
    
    </header>
  )
}