import ReactMarkDown from "react-markdown";

export default function Recipe(props) {
  return (
    props.recipe && (
      <section className="rec">
        <ReactMarkDown>{props.recipe}</ReactMarkDown>
      </section>
    )
  );
}
